// YouTube Data API integration
const API_KEY = 'YOUR_YOUTUBE_DATA_API_KEY'; // Replace with actual API key

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'fetchVideoInsights') {
    fetchVideoData(request.videoId)
      .then(insights => {
        sendResponse({ success: true, insights });
      })
      .catch(error => {
        sendResponse({ success: false, error: error.message });
      });
    return true; // Indicates we wish to send a response asynchronously
  }
});

async function fetchVideoData(videoId) {
  try {
    // Fetch video statistics
    const statsResponse = await fetch(
      `https://youtube.googleapis.com/youtube/v3/videos?part=statistics,snippet&id=${videoId}&key=${API_KEY}`
    );
    const statsData = await statsResponse.json();

    // Fetch related videos for tag suggestions
    const relatedResponse = await fetch(
      `https://youtube.googleapis.com/youtube/v3/search?part=snippet&relatedToVideoId=${videoId}&type=video&key=${API_KEY}&maxResults=5`
    );
    const relatedData = await relatedResponse.json();

    // Extract insights
    const video = statsData.items[0];
    const statistics = video.statistics;
    const snippet = video.snippet;

    return {
      views: parseInt(statistics.viewCount || 0),
      likes: parseInt(statistics.likeCount || 0),
      comments: parseInt(statistics.commentCount || 0),
      tags: snippet.tags || [],
      recommendedTags: relatedData.items.map(item => 
        item.snippet.title.split(' ')[0]
      ).slice(0, 5)
    };
  } catch (error) {
    console.error('YouTube API Error:', error);
    throw new Error('Failed to fetch video insights');
  }
}

// Optional: Add functionality to track user interactions or gather more data
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && /youtube\.com\/watch/.test(tab.url)) {
    chrome.tabs.sendMessage(tabId, { action: 'initializeOverlay' });
  }
});

// Add error handling for API key
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.set({
    youtubeApiKey: 'YOUR_YOUTUBE_DATA_API_KEY'
  }, () => {
    console.log('Default API key set');
  });
});
