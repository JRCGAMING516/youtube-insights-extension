# YouTube Insights Chrome Extension

## Features
- Real-time video analytics from YouTube Data API
- Performance metrics tracking
- Tag recommendations
- Easy-to-use overlay on YouTube watch pages

## Prerequisites
- Chrome Browser
- YouTube Data API Key (free from Google Cloud Console)

## Installation
1. Obtain a YouTube Data API Key:
   - Go to [Google Cloud Console](https://console.cloud.google.com/)
   - Create a new project
   - Enable YouTube Data API v3
   - Create credentials (API Key)

2. Configure the Extension:
   - Open `background.js`
   - Replace `'YOUR_YOUTUBE_DATA_API_KEY'` with your actual API key

3. Load the Extension in Chrome:
   - Open Chrome and go to `chrome://extensions/`
   - Enable "Developer mode"
   - Click "Load unpacked" and select the extension directory

## Development
- Requires Chrome Browser
- Manifest V3 compatible
- Node.js and npm for packaging

## Packaging
```bash
npm install
npm run package
```

## Roadmap
- [ ] Add more detailed analytics
- [ ] Implement tag suggestion AI
- [ ] Create custom dashboard

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

## Troubleshooting
- Ensure API key is correctly set
- Check Chrome Developer Console for any errors
- Verify YouTube Data API is enabled in Google Cloud Console
