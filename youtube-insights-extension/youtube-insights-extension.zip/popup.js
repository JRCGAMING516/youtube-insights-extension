document.addEventListener('DOMContentLoaded', () => {
  // Add any interactive functionality for the popup
  chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
    const currentTab = tabs[0];
    if (currentTab.url.includes('youtube.com/watch')) {
      const urlParams = new URLSearchParams(new URL(currentTab.url).search);
      const videoId = urlParams.get('v');
      
      if (videoId) {
        chrome.runtime.sendMessage(
          { action: 'fetchVideoInsights', videoId },
          (response) => {
            if (response.success) {
              displayVideoInsights(response.insights);
            }
          }
        );
      }
    }
  });
});

function displayVideoInsights(insights) {
  const insightsContainer = document.createElement('div');
  insightsContainer.innerHTML = `
    <h4>Current Video Insights</h4>
    <p>Views: ${insights.views.toLocaleString()}</p>
    <p>Likes: ${insights.likes.toLocaleString()}</p>
    <p>Comments: ${insights.comments.toLocaleString()}</p>
    <div>
      <strong>Tags:</strong>
      ${insights.tags.map(tag => `<span style="background:blue; margin:2px; padding:2px; border-radius:3px;">${tag}</span>`).join('')}
    </div>
  `;
  
  document.body.appendChild(insightsContainer);
}
